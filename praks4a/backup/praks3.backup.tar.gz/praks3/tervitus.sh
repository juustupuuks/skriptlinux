#!/bin/bash
# Autor: [Joonas]
# Kuupäev: 08.09.2025
# Kirjeldus: Skript küsib kasutajalt ees- ja perenime ning tervitab teda.

echo -n "Sisesta oma ees- ja perenimi: "
read eesnimi perenimi

echo "Sinu eesnimi on $eesnimi ja perenimi on $perenimi"
echo "Tere tulemast, $eesnimi $perenimi!"
##testimiseks
